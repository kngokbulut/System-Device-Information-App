from tkinter import *
import tkinter as tk

root = tk.Tk()
root.title("System & Device İnformation App")
root.geometry("1000x650")

e = tk.Entry(root)
e.grid(row=1, rowspan=9, column=2,padx=10,pady=10,ipadx=200,ipady=300)
import psutil
import platform
from datetime import datetime

def get_size(bytes, suffix="B"):
    """
    Scale bytes to its proper format
    e.g:
        1253656 => '1.20MB'
        1253656678 => '1.17GB'
    """
    factor = 1024
    for unit in ["", "K", "M", "G", "T", "P"]:
        if bytes < factor:
            return f"{bytes:.2f}{unit}{suffix}"
        bytes /= factor

# System Information
uname = platform.uname()
# Boot Time
boot_time_timestamp = psutil.boot_time()
bt = datetime.fromtimestamp(boot_time_timestamp)
# let's print CPU information
cpufreq = psutil.cpu_freq()
# Memory Information
# get the memory details
svmem = psutil.virtual_memory()
# get the swap memory details (if exists)
swap = psutil.swap_memory()
# Disk Information
# get all disk partitions
partitions = psutil.disk_partitions()

for partition in partitions:
    {partition.device}
    {partition.mountpoint}
    {partition.fstype}
    try:
        partition_usage = psutil.disk_usage(partition.mountpoint)
    except PermissionError:
    # this can be catched due to the disk that
    # isn't ready
        continue
        {get_size(partition_usage.total)}
        {get_size(partition_usage.used)}
        {get_size(partition_usage.free)}
        {partition_usage.percent}

# Network information
# get all network interfaces (virtual and physical)
if_addrs = psutil.net_if_addrs()
for interface_name, interface_addresses in if_addrs.items():
    for address in interface_addresses:
        {interface_name}
        if str(address.family) == 'AddressFamily.AF_INET':
            {address.address}
            {address.broadcast}
            {address.broadcast}
        elif str(address.family) == 'AddressFamily.AF_PACKET':
            {address.address}
            {address.netmask}
            {address.broadcast}

# get IO statistics since boot
net_io = psutil.net_io_counters()










def button_click1(text):
    e.delete(0, END)
    e.insert(0, text)



def button_click2(text):
    e.delete(0, END)
    e.insert(0, text)


def button_click3(text):
    e.delete(0, END)
    e.insert(0, text)


def button_click4(text):
    e.delete(0, END)
    e.insert(0, text)


def button_click5(text):
    e.delete(0, END)
    e.insert(0, text)



def button_click6(text):
    e.delete(0, END)
    e.insert(0, text)
    partitions = psutil.disk_partitions()

    for partition in partitions:
        {partition.device}
        {partition.mountpoint}
        {partition.fstype}
        try:
            partition_usage = psutil.disk_usage(partition.mountpoint)
        except PermissionError:
            # this can be catched due to the disk that
            # isn't ready
            continue
        {get_size(partition_usage.total)}
        {get_size(partition_usage.used)}
        {get_size(partition_usage.free)}
        {partition_usage.percent}


def button_click7(text):
    e.delete(0, END)
    e.insert(0, text)


def button_click8(text):
    e.delete(0, END)
    e.insert(0, text)


def button_clear():
    e.delete(0, END)


# Define Buttons
button_1 = Button(root, text="System Information", padx=50, pady=15, command=lambda:button_click1(f"System:{uname.system}" 
                                                                                                  f"Node Name:{uname.node}"
                                                                                                  f"Release: {uname.release}"
                                                                                                  f"Version: {uname.version}"
                                                                                                  f"Machine: {uname.machine}"
                                                                                                  f"Processor: {uname.processor}"))

button_2 = Button(root, text="Boot Time", padx=50, pady=15, command=lambda:button_click2(f"Boot Time: {bt.year}/{bt.month}/{bt.day} {bt.hour}:{bt.minute}:{bt.second}"))

button_3 = Button(root, text="CPU Info", padx=50, pady=15, command=lambda:button_click3(f"Physical cores: {psutil.cpu_count(logical=False)}"
                                                                                        f"Total cores: {psutil.cpu_count(logical=True)}"
                                                                                        f"Max Frequency: {cpufreq.max:.2f}Mhz"
                                                                                        f"Min Frequency: {cpufreq.min:.2f}Mhz"
                                                                                        f"Current Frequency: {cpufreq.current:.2f}Mhz"))

button_4 = Button(root, text="Memory Information", padx=50, pady=15, command=lambda:button_click4(f"Total: {get_size(svmem.total)}"
                                                                                                  f"Available: {get_size(svmem.available)}"
                                                                                                  f"Used: {get_size(svmem.used)}"
                                                                                                  f"Percentage: {svmem.percent}%"))

button_5 = Button(root, text="SWAP", padx=50, pady=15, command=lambda:button_click5(f"Total: {get_size(swap.total)}"
                                                                                    f"Free: {get_size(swap.free)}"
                                                                                    f"Used: {get_size(swap.used)}"
                                                                                    f"Percentage: {swap.percent}%"))

button_6 = Button(root, text="Disk Information", padx=50, pady=15, command=lambda:button_click6(f"=== Device: {partition.device} ==="
                                                                                                f"  Mountpoint: {partition.mountpoint}"
                                                                                                f"  File system type: {partition.fstype}"
                                                                                                f"  Total Size: {get_size(partition_usage.total)}"
                                                                                                f"  Used: {get_size(partition_usage.used)}"
                                                                                                f"  Free: {get_size(partition_usage.free)}"
                                                                                                f"  Percentage: {partition_usage.percent}%"))

button_7 = Button(root, text="Network Information", padx=50, pady=15, command=lambda:button_click7(f"=== Interface: {interface_name} ==="
                                                                                                   f"  IP Address: {address.address}"
                                                                                                   f"  Netmask: {address.netmask}"
                                                                                                   f"  Broadcast IP: {address.broadcast}"
                                                                                                   f"  MAC Address: {address.address}"
                                                                                                   f"  Netmask: {address.netmask}"
                                                                                                   f"  Broadcast MAC: {address.broadcast}"))

button_8 = Button(root, text="get IO statistics since boot", padx=50, pady=15, command=lambda:button_click8(f"Total Bytes Sent: {get_size(net_io.bytes_sent)}"
                                                                                                            f"Total Bytes Received: {get_size(net_io.bytes_recv)}"))
button_9 = Button(root, text="CLEAR", padx=50, pady=15, command=button_clear)

# Put the buttons on the screen

button_1.grid(row=1, rowspan=1, column=1, columnspan=1)
button_2.grid(row=2, rowspan=1, column=1, columnspan=1)
button_3.grid(row=3, rowspan=1, column=1, columnspan=1)
button_4.grid(row=4, rowspan=1, column=1, columnspan=1)
button_5.grid(row=5, rowspan=1, column=1, columnspan=1)
button_6.grid(row=6, rowspan=1, column=1, columnspan=1)
button_7.grid(row=7, rowspan=1, column=1, columnspan=1)
button_8.grid(row=8, rowspan=1, column=1, columnspan=1)
button_9.grid(row=9, rowspan=1, column=1, columnspan=1)

root.mainloop()
